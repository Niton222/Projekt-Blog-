const express = require('express');
const bodyParser = require('body-parser');
const fs = require('fs');
const path = require('path');

const app = express();

app.set('view engine', 'ejs');
app.use(bodyParser.urlencoded({ extended: true }));

// Serve static files from the 'public' directory
app.use(express.static('public'));
// Host the 'blogs' directory
app.use('/blogs', express.static('blogs'));

// Route to render the home page with posts
app.get('/', function(req, res){
  // Read the list of files in the 'blogs' directory
  fs.readdir(path.join(__dirname, 'blogs'), (err, files) => {
    if (err) {
      console.error('Error reading blog files:', err);
      return res.status(500).send('Error reading blog files');
    }
    // Extract filenames without extension
    const blogPostNames = files.map(file => path.parse(file).name);
    res.render('home', { blogPostNames: blogPostNames });
  });
});

// Route to handle new post submission
app.post('/compose', function(req, res){
  const newPost = {
    title: req.body.postTitle,
    content: req.body.postContent
  };
  // Save each blog post to a separate HTML file in the 'blogs' directory
  const fileName = `${newPost.title.replace(/\s+/g, '-').toLowerCase()}.html`;
  const filePath = path.join(__dirname, 'blogs', fileName);
  fs.writeFile(filePath, `<html><a href="/">Home</a><head><title>${newPost.title}</title><link rel="stylesheet" type="text/css" href="../blogs.css"></head><body><h1>${newPost.title}</h1><p>${newPost.content}</p></body></html>`, (err) => {
    if (err) {
      console.error(err);
      return res.status(500).send('Error saving post to file system');
    }
    console.log(`Blog post saved to ${filePath}`);
    res.redirect('/');
  });
});

// Route to delete a blog post
app.post('/delete', function(req, res){
  const fileName = req.body.fileName; // Get the file name from the request
  const filePath = path.join(__dirname, 'blogs', fileName + '.html');
  // Remove the blog post file
  fs.unlink(filePath, (err) => {
    if (err) {
      console.error(err);
      return res.status(500).send('Error deleting blog post file');
    }
    console.log(`Deleted blog post file: ${filePath}`);
    res.redirect('/');
  });
});

// Route to serve individual blog post pages with ".html" extension
app.get('/blogs/:fileName.html', function(req, res) {
  const fileName = req.params.fileName; // Get the file name from the request
  const filePath = path.join(__dirname, 'blogs', `${fileName}.html`); // Construct the file path
  // Check if the file exists
  fs.access(filePath, fs.constants.F_OK, (err) => {
    if (err) {
      console.error('Error accessing file:', err);
      return res.status(404).send('Blog post not found');
    }
    // If the file exists, send the file to the client
    res.sendFile(filePath);
  });
});

// Start the server
const PORT = process.env.PORT || 3000;
app.listen(PORT, function() {
  console.log(`Server is running on port ${PORT}`);
});

app.get('/edit/:fileName', function(req, res) {
  const fileName = req.params.fileName; // Get the file name from the request
  const filePath = path.join(__dirname, 'blogs', `${fileName}.html`); // Construct the file path
  // Read the blog post file
  fs.readFile(filePath, 'utf8', (err, data) => {
    if (err) {
      console.error('Error reading blog post file:', err);
      return res.status(500).send('Error reading blog post file');
    }
    // Extract title and content from the blog post file
    const matchTitle = data.match(/<title>(.*?)<\/title>/);
    const matchContent = data.match(/<body>(.*?)<\/body>/s);
    const title = matchTitle ? matchTitle[1] : '';
    const content = matchContent ? matchContent[1] : '';
    // Render the edit page with the blog post data
    res.render('edit', { fileName: fileName, post: { title: title, content: content } });
  });
});

// Route to handle editing of a specific blog post
app.post('/edit/:fileName', function(req, res) {
  const fileName = req.params.fileName; // Get the file name from the request
  const filePath = path.join(__dirname, 'blogs', `${fileName}.html`); // Construct the file path
  const newTitle = req.body.postTitle;
  const newContent = req.body.postContent;
  // Update the blog post file with the new title and content
  const updatedContent = `<html><head><title>${newTitle}</title><link rel="stylesheet" type="text/css" href="../style.css"></head><body><h1>${newTitle}</h1><p>${newContent}</p></body></html>`;
  fs.writeFile(filePath, updatedContent, (err) => {
    if (err) {
      console.error('Error updating blog post file:', err);
      return res.status(500).send('Error updating blog post file');
    }
    console.log(`Blog post ${fileName} updated`);
    res.redirect(`/blogs/${fileName}.html`);
  });
});

